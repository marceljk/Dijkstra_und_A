/**
 *
 */
public class Dijkstra {

    public Dijkstra() {

    }

    private void initialisiere() {

    }

    private void distanz_update() {

    }

    private void erstelleKuerzestenPfad() {

    }
}